# 萬妖文書版 / Wanyao Learning Archive

Traditional Chinese and English learning directory, downloaded from https://wanyao-wenshu.pages.dev/ on 2026-09-10 and adapted for GitHub Pages. Eight original station links, screenshots, QR codes, category navigation, last-visited state, videos and clipboard copying are retained. External learning sites and videos retain their original languages. English station names are descriptive translations.

## Preview

Run `python3 -m http.server 8000` in this directory, then open http://localhost:8000. No build or package installation is required.

## Publish

The `main` branch publishes using `.github/workflows/pages.yml`. In repository **Settings → Pages → Build and deployment → Source**, choose **GitHub Actions**. Re-run the workflow if Pages was enabled after the first push.

Expected project URL: https://mewomuguo.github.io/prlearning/

All local asset paths are relative and support deployment in a subdirectory. The workflow publishes only website files, excluding project documentation and Git metadata.

## Maintain

- `data/sites.js`: eight stations, bilingual names/descriptions, destinations and media paths.
- `index.html`: page shell and bilingual header.
- `js/app.js`: navigation, overview, details and clipboard feedback.
- `js/status.js`: connection probes. “Reachable” only indicates a network response; opaque cross-origin responses cannot confirm HTTP success or service health.
- `css/style.css`: original styling with bilingual wrapping adjustments.
- `assets/`: original screenshots, QR codes and decoration.

Original visitor counters were removed so this deployment does not report visits to the source site's analytics. Source media and Chinese copy retain their original authorship; this repository does not grant new rights to third-party material.
