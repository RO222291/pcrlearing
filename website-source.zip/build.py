from pathlib import Path
import zipfile
root = Path(__file__).resolve().parent
out = root.parent / 'pcrlearing-publish'
out.mkdir(exist_ok=True)
html = (root / 'index.html').read_text()
html = html.replace('<link rel="stylesheet" href="style.css">', '<style>'+ (root/'style.css').read_text() + '</style>')
for name in ['data.js','app.js']:
    html = html.replace(f'<script src="{name}"></script>', '<script>' + (root/name).read_text() + '</script>')
(out/'index.html').write_text(html)
(out/'.nojekyll').touch()
(out/'README.md').write_text((root/'README.md').read_text())
with zipfile.ZipFile(out/'website-source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in root.iterdir():
        if p.is_file(): z.write(p,p.name)
print('Built standalone website and editable source archive.')
