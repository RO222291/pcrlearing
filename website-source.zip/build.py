from pathlib import Path
import base64,zipfile
root=Path(__file__).resolve().parent;out=root.parent/'pcrlearing-publish';out.mkdir(exist_ok=True)
s=(root/'index.html').read_text();s=s.replace('<link rel="stylesheet" href="css/style.css">','<style>'+(root/'css/style.css').read_text()+'</style>')
for p in ['data/sites.js','js/app.js','js/status.js','js/bilingual.js']:s=s.replace(f'<script src="{p}"></script>','<script>'+(root/p).read_text()+'</script>')
for p in (root/'assets').rglob('*'):
 if p.is_file():s=s.replace(p.relative_to(root).as_posix(),'data:'+('image/svg+xml' if p.suffix=='.svg' else 'image/png')+';base64,'+base64.b64encode(p.read_bytes()).decode())
(out/'index.html').write_text(s);(out/'README.md').write_text((root/'README.md').read_text());(out/'.nojekyll').touch()
with zipfile.ZipFile(out/'website-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in root.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(root))
print('Built restored bilingual directory.')
