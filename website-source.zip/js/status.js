(function () {
  'use strict';

  const TIMEOUT = 8000;
  const STATUS_LABELS = {
    checking: '偵測中 / Checking',
    ok: '可連線 / Reachable',
    down: '暫時無法連線 / Unreachable',
  };

  function updateDots(site, state) {
    document.querySelectorAll(`.status-dot[data-id="${site.id}"]`).forEach((dot) => {
      dot.dataset.state = state;
      dot.setAttribute('aria-label', `${site.siteName}：${STATUS_LABELS[state]}`);
      const text = dot.parentElement?.querySelector('.status-text');
      if (text) text.textContent = STATUS_LABELS[state];
    });
  }

  // 各站為 Cloudflare Pages 靜態站，對不存在路徑會回 SPA fallback（200 + HTML），
  // 不能用 Image() 探測；改用 no-cors fetch——收到任何回應（opaque）即視為連線正常，
  // 只有網路錯誤或逾時才判斷為無法連線。
  async function probe(site) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), TIMEOUT);
    try {
      const probeUrl = new URL(site.probe || '/', site.url);
      await fetch(probeUrl.toString(), {
        mode: 'no-cors',
        cache: 'no-store',
        signal: controller.signal,
      });
      return 'ok';
    } catch (error) {
      return 'down';
    } finally {
      window.clearTimeout(timer);
    }
  }

  function initialize() {
    const sites = Array.isArray(window.WENSHU_SITES) ? window.WENSHU_SITES : [];
    window.WENSHU_STATUS = Object.fromEntries(sites.map((site) => [site.id, 'checking']));

    for (const site of sites) {
      updateDots(site, 'checking');
      probe(site).then((state) => {
        window.WENSHU_STATUS[site.id] = state;
        updateDots(site, state);

        const panel = document.getElementById('panel');
        if (panel?.dataset.view === 'overview') {
          window.WENSHU_APP?.renderOverview();
        }
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize, { once: true });
  } else {
    initialize();
  }
})();
