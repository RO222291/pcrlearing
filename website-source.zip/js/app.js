(function () {
  'use strict';

  const FOLDERS_KEY = 'wanyao.folders';
  const LAST_KEY = 'wanyao.last';
  const GROUPS = [
    { id: 'guowen', label: '國語文 / Chinese' },
    { id: 'english', label: '英文 / English' },
    { id: 'math', label: '數學 / Math' },
    { id: 'science', label: '自然 / Science' },
    { id: 'habit', label: '自我領導 / Self-leadership' },
  ];
  const STATUS_LABELS = {
    checking: '偵測中 / Checking',
    ok: '可連線 / Reachable',
    down: '暫時無法連線 / Unreachable',
  };
  let sidebar;
  let panel;
  let sidebarToggle;
  let folderState = readFolderState();

  function readStorage(key) {
    try {
      return localStorage.getItem(key);
    } catch (error) {
      return null;
    }
  }

  function writeStorage(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch (error) {
      // 私密瀏覽或停用儲存時，仍維持本次瀏覽功能。
    }
  }

  function readFolderState() {
    const defaults = Object.fromEntries(GROUPS.map((group) => [group.id, true]));
    const stored = readStorage(FOLDERS_KEY);
    if (!stored) return defaults;

    try {
      const parsed = JSON.parse(stored);
      for (const group of GROUPS) {
        if (typeof parsed[group.id] === 'boolean') defaults[group.id] = parsed[group.id];
      }
    } catch (error) {
      return defaults;
    }
    return defaults;
  }

  function escapeHtml(value) {
    return String(value)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function getStatus(id) {
    const state = window.WENSHU_STATUS?.[id];
    return STATUS_LABELS[state] ? state : 'checking';
  }

  function statusDot(site) {
    const state = getStatus(site.id);
    return `<span class="status-dot" data-id="${escapeHtml(site.id)}" data-state="${state}" aria-label="${escapeHtml(site.siteName)}：${STATUS_LABELS[state]}" role="status"></span>`;
  }

  function renderSidebar() {
    const lastId = readStorage(LAST_KEY);
    const groupsHtml = GROUPS.map((group) => {
      const sites = window.WENSHU_SITES.filter((site) => site.group === group.id);
      const expanded = folderState[group.id];
      const rows = sites.map((site) => `
        <div class="site-row" data-id="${escapeHtml(site.id)}">
          <button class="site-select" type="button" data-id="${escapeHtml(site.id)}">
            ${statusDot(site)}
            <span class="site-name">
              ${escapeHtml(site.siteName)}
              ${site.id === lastId ? '<small class="last-used">上次使用 / Last visited</small>' : ''}
            </span>
          </button>
          <a class="external-link" href="${escapeHtml(site.url)}" target="_blank" rel="noopener" aria-label="在新分頁開啟 / Open in a new tab: ${escapeHtml(site.siteName)}">↗</a>
        </div>
      `).join('');

      return `
        <section class="folder${expanded ? '' : ' is-collapsed'}" data-group="${group.id}">
          <button class="folder-heading" type="button" aria-expanded="${expanded}" data-group="${group.id}">
            <span class="folder-caret" aria-hidden="true">${expanded ? '▾' : '▸'}</span>${group.label}
          </button>
          <div class="folder-sites">${rows}</div>
        </section>
      `;
    }).join('');

    sidebar.innerHTML = `
      <button class="overview-button" type="button">八站總覽 / All eight stations</button>
      ${groupsHtml}
    `;

    sidebar.querySelector('.overview-button').addEventListener('click', () => {
      renderOverview();
      closeMobileSidebar();
    });
    sidebar.querySelectorAll('.folder-heading').forEach((button) => {
      button.addEventListener('click', () => toggleFolder(button.dataset.group));
    });
    sidebar.querySelectorAll('.site-select').forEach((button) => {
      button.addEventListener('click', () => selectSite(button.dataset.id));
    });
  }

  function toggleFolder(groupId) {
    folderState[groupId] = !folderState[groupId];
    writeStorage(FOLDERS_KEY, JSON.stringify(folderState));

    const folder = sidebar.querySelector(`.folder[data-group="${groupId}"]`);
    const button = folder?.querySelector('.folder-heading');
    const caret = folder?.querySelector('.folder-caret');
    if (!folder || !button || !caret) return;

    folder.classList.toggle('is-collapsed', !folderState[groupId]);
    button.setAttribute('aria-expanded', String(folderState[groupId]));
    caret.textContent = folderState[groupId] ? '▾' : '▸';
  }

  function updateActiveNavigation(id) {
    sidebar.querySelectorAll('.site-row').forEach((row) => {
      row.classList.toggle('is-active', row.dataset.id === id);
    });
    sidebar.querySelector('.overview-button')?.classList.toggle('is-active', !id);
  }

  function updateLastUsed(id) {
    sidebar.querySelectorAll('.last-used').forEach((label) => label.remove());
    const name = sidebar.querySelector(`.site-row[data-id="${id}"] .site-name`);
    if (name) name.insertAdjacentHTML('beforeend', '<small class="last-used">上次使用 / Last visited</small>');
  }

  function closeMobileSidebar() {
    sidebar.classList.remove('is-open');
    sidebarToggle?.setAttribute('aria-expanded', 'false');
  }

  function selectSite(id) {
    const site = window.WENSHU_SITES.find((item) => item.id === id);
    if (!site || !panel) return;

    writeStorage(LAST_KEY, site.id);
    updateLastUsed(site.id);
    updateActiveNavigation(site.id);
    panel.dataset.view = 'site';
    panel.innerHTML = `
      <article class="detail-layout">
        <div class="media-col">
          <div class="media-card">
            <img class="site-screenshot" src="${escapeHtml(site.screenshot)}" alt="${escapeHtml(site.siteName)}網站畫面 / Website preview" onerror="this.hidden=true">
          </div>
          ${site.youtube ? `
          <div class="media-card video-card">
            <iframe src="https://www.youtube-nocookie.com/embed/${escapeHtml(site.youtube)}" title="${escapeHtml(site.videoTitle || '影片解說 / Video introduction')}" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            <p class="video-note">${escapeHtml(site.videoTitle || '影片解說 / Video introduction')}</p>
          </div>` : ''}
        </div>
        <div class="detail-copy">
          <span class="grade-badge">${escapeHtml(site.gradeDetail)}</span>
          <h1 class="detail-title">${escapeHtml(site.siteName)}</h1>
          <p class="tagline">${escapeHtml(site.tagline)}</p>
          <p class="stats">${escapeHtml(site.stats)}</p>
          <div class="scenario-box">
            <strong>適合情境 / Suggested use</strong>
            <span>${escapeHtml(site.scenario)}</span>
          </div>
          <a class="enter-btn" href="${escapeHtml(site.url)}" target="_blank" rel="noopener">進入網站 / Visit website</a>
          <div class="share-row">
            <img class="qr-image" src="${escapeHtml(site.qr)}" alt="${escapeHtml(site.siteName)}網址 QR Code" onerror="this.hidden=true">
            <div class="share-copy">
              <p>${escapeHtml(site.url)}</p>
              <button class="copy-button" type="button" data-url="${escapeHtml(site.url)}">複製網址 / Copy URL</button>
            </div>
          </div>
        </div>
      </article>
    `;

    panel.querySelector('.copy-button').addEventListener('click', copySiteUrl);
    closeMobileSidebar();

    if (window.matchMedia('(max-width: 768px)').matches) {
      requestAnimationFrame(() => panel.scrollIntoView({ behavior: 'smooth', block: 'start' }));
    }
  }

  async function copySiteUrl(event) {
    const button = event.currentTarget;
    const originalText = button.textContent;
    try {
      await navigator.clipboard.writeText(button.dataset.url);
      button.textContent = '已複製 ✓ / Copied';
    } catch (error) {
      button.textContent = '複製失敗 / Copy failed';
    }
    window.setTimeout(() => {
      button.textContent = originalText;
    }, 2000);
  }

  function renderOverview() {
    if (!panel) return;
    updateActiveNavigation(null);
    panel.dataset.view = 'overview';

    const rows = window.WENSHU_SITES.map((site) => {
      const group = GROUPS.find((item) => item.id === site.group);
      return `
        <tr>
          <td><button class="table-site-button" type="button" data-id="${escapeHtml(site.id)}">${escapeHtml(site.siteName)}</button></td>
          <td>${escapeHtml(group?.label || site.group)}</td>
          <td>${escapeHtml(site.stats)}</td>
          <td class="status-cell">${statusDot(site)} <span class="status-text">${STATUS_LABELS[getStatus(site.id)]}</span></td>
        </tr>
      `;
    }).join('');

    panel.innerHTML = `
      <section class="overview">
        <p class="section-kicker">依科目，找到最適合的一站 / Find your next station by subject</p>
        <h1 class="page-title">八站自學總覽 / Explore eight learning stations</h1>
        <p class="lead">從字音字形、英文單字、數學銜接到自然科與七個習慣，一頁掌握適用年段、內容與目前連線狀態。 / Explore Chinese, English vocabulary, math, science and the seven habits. Compare content and connection status in one place.</p>

        <article class="detail-copy">
          <h2>想養成每天自學的習慣？ / Ready to make learning a daily habit?</h2>
          <p>萬妖習行錄是這八站的冒險護照——選任務、蓋印章、累積連續天數，把自學變成每天走一小步的遊戲。 / The Learning Passport connects these eight stations: choose missions, collect stamps and build a daily streak, one small step at a time.</p>
          <a class="enter-btn" href="https://self-learning-passport.pages.dev/" target="_blank" rel="noopener">前往萬妖習行錄 / Learning Passport ↗</a>
          <div class="media-card video-card">
            <iframe src="https://www.youtube-nocookie.com/embed/WQ4UWBR6Knc" title="兩分鐘看懂萬妖習行錄怎麼用 / Two-minute Learning Passport guide (Chinese)" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            <p class="video-note">兩分鐘看懂萬妖習行錄怎麼用 / Two-minute Learning Passport guide (Chinese)</p>
          </div>
        </article>

        <section class="overview-section" aria-labelledby="comparison-title">
          <h2 id="comparison-title">八站對照表 / Compare stations</h2>
          <div class="table-wrap">
            <table class="comparison-table">
              <thead>
                <tr><th>站名 / Station</th><th>科目 / Subject</th><th>內容 / Content</th><th>狀態 / Status</th></tr>
              </thead>
              <tbody>${rows}</tbody>
            </table>
          </div>
        </section>
      </section>
    `;

    panel.querySelectorAll('.table-site-button').forEach((button) => {
      button.addEventListener('click', () => selectSite(button.dataset.id));
    });
  }

  function initialize() {
    sidebar = document.getElementById('sidebar');
    panel = document.getElementById('panel');
    sidebarToggle = document.getElementById('sidebar-toggle');
    if (!sidebar || !panel) return;

    renderSidebar();
    document.getElementById('overview-link')?.addEventListener('click', renderOverview);
    sidebarToggle?.addEventListener('click', () => {
      const isOpen = sidebar.classList.toggle('is-open');
      sidebarToggle.setAttribute('aria-expanded', String(isOpen));
    });

    const lastId = readStorage(LAST_KEY);
    if (lastId && window.WENSHU_SITES.some((site) => site.id === lastId)) {
      selectSite(lastId);
    } else {
      renderOverview();
    }
  }

  window.WENSHU_APP = { selectSite, renderOverview };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize, { once: true });
  } else {
    initialize();
  }
})();
