// Keep Chinese source wording first, with a separate English line.
(function () {
  'use strict';
  const observer = new MutationObserver(format);
  function format() {
    observer.disconnect();
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (node.textContent.includes(' / ') && /[\u3400-\u9fff]/.test(node.textContent) &&
          !node.parentElement.closest('script,style,noscript,.bilingual-copy')) nodes.push(node);
    }
    for (const node of nodes) {
      const value = node.textContent;
      const cut = value.indexOf(' / ');
      const wrapper = document.createElement('span');
      wrapper.className = 'bilingual-copy';
      const zh = document.createElement('span');
      zh.lang = 'zh-Hant'; zh.className = 'copy-zh'; zh.textContent = value.slice(0, cut).trim();
      const en = document.createElement('span');
      en.lang = 'en'; en.className = 'copy-en'; en.textContent = value.slice(cut + 3).trim();
      wrapper.append(zh, en); node.replaceWith(wrapper);
    }
    observer.observe(document.body, {subtree:true, childList:true, characterData:true});
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', format, {once:true});
  else format();
})();
