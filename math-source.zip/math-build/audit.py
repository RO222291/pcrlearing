from pathlib import Path
import json,re,collections,hashlib
D={}
for p in Path('math-translations').rglob('*.json'):
 try:D.update(json.loads(re.sub(r'^```(?:json)?\s*|\s*```$','',p.read_text().strip())))
 except:pass
mismatches=[];missing=set();count=0
for p in Path('math-original/data/questions').glob('*.json'):
 bank=json.loads(p.read_text())
 for group in ['basicMastery','conceptId','errorDiagnosis','contextApplication']:
  for q in bank.get(group,[]):
   count+=1
   for key in ['stem','explanation','options']:
    v=q.get(key,[]);values=v if isinstance(v,list) else [v]
    for zh in values:
     if not isinstance(zh,str) or not re.search('[\u3400-\u9fff]',zh):continue
     en=D.get(zh)
     if not en:missing.add(zh);continue
     numbers=lambda s:collections.Counter(re.findall(r'\d+(?:\.\d+)?',s.replace(',','')))
     if numbers(zh)!=numbers(en):mismatches.append({'node':p.stem,'id':q['id'],'field':key,'zh':zh,'en':en})
Path('math-build/numeric-review.json').write_text(json.dumps(mismatches,ensure_ascii=False,indent=2));print('Questions',count,'missing fields',len(missing),'numeric differences',len(mismatches));print(json.dumps(mismatches[:5],ensure_ascii=False,indent=2))
