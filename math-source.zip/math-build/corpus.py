from pathlib import Path
from html.parser import HTMLParser
import json,re,html
han=lambda s:bool(re.search('[\u3400-\u9fff]',s))
strings=set()
class Texts(HTMLParser):
 def handle_data(self,s):
  if han(s):strings.add(s.strip())
 def handle_starttag(self,t,attrs):
  for k,v in attrs:
   if k in ['title','aria-label','placeholder','alt'] and v and han(v):strings.add(v)
for p in Path('math-original').glob('*.html'):Texts().feed(p.read_text())
def scan(x):
 if isinstance(x,str) and han(x):strings.add(x)
 elif isinstance(x,dict):
  for v in x.values():scan(v)
 elif isinstance(x,list):
  for v in x:scan(v)
for p in Path('math-original/data').glob('*.json'):scan(json.loads(p.read_text()))
for s in json.loads(Path('math-build/ui-literals.json').read_text()):
 if '<' in s and '>' in s:Texts().feed(s)
 else:strings.add(s.strip())
for d in json.loads(Path('math-build/ui-templates.json').read_text()):
 s=d['source']
 if '<' in s and '>' in s:Texts().feed(s)
 else:strings.add(s.strip())
items=sorted(s for s in strings if s)
Path('math-build/ui-corpus.json').write_text(json.dumps(items,ensure_ascii=False,indent=2))
Path('math-build/translation-input').mkdir(exist_ok=True)
for i in range(0,len(items),80):
 batch=items[i:i+80];Path(f'math-build/translation-input/ui-{i//80:02}.html').write_text('<html><body><pre>'+html.escape(json.dumps(batch,ensure_ascii=False))+'</pre></body></html>')
print(len(items),'UI strings')
