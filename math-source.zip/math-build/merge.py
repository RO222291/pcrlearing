from pathlib import Path
import re,json
D={}
for p in sorted(Path('math-translations').rglob('*.json')):
 try:D.update(json.loads(re.sub(r'^```(?:json)?\s*|\s*```$','',p.read_text().strip())))
 except:pass
p=Path('math-build/overrides.json')
if p.exists():D.update(json.loads(p.read_text()))
D={k:v for k,v in D.items() if isinstance(v,str) and v and not re.search('[\u3400-\u9fff]',v)}
Path('pcrlearing-publish').mkdir(exist_ok=True)
Path('pcrlearing-publish/math-en.js').write_text('globalThis.MATH_EN='+json.dumps(D,ensure_ascii=False)+';')
print('Merged',len(D),'translations')
