exec(open('math-build/translate-batches.py').read().split('for round in range(4):')[0])
import concurrent.futures
stamp=str(int(time.time()))
def work(args):
 round,i,batch=args;dest=Path(f'math-translations/fill-{stamp}-{round}-{i:03}.json');src=Path(f'math-build/translation-input/fill-{stamp}-{round}-{i:03}.html');src.write_text('<html><body><pre>'+html.escape(json.dumps(batch,ensure_ascii=False))+'</pre></body></html>')
 for attempt in range(6):
  try:r=subprocess.run(['firecrawl','parse',str(src),'--query',query,'-o',str(dest)],capture_output=True,text=True,timeout=240)
  except subprocess.TimeoutExpired:continue
  if r.returncode==0:
   try:
    result=parse_json(dest);dest.write_text(json.dumps(result,ensure_ascii=False,indent=2));return dest.name,len(set(batch)&result.keys()),len(batch)
   except:pass
  time.sleep(20)
 return dest.name,'FAILED',len(batch)
for round in range(4):
 d=merged();missing=sorted(need-d.keys());print('Round',round,'missing',len(missing),'of',len(need),flush=True)
 if not missing:break
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for f in concurrent.futures.as_completed([pool.submit(work,(round,i//100,missing[i:i+100])) for i in range(0,len(missing),100)]):print(*f.result(),flush=True)
 d=merged();Path('pcrlearing-publish/math-en.js').write_text('globalThis.MATH_EN='+json.dumps(d,ensure_ascii=False)+';')
d=merged();missing=sorted(need-d.keys());Path('math-build/missing.json').write_text(json.dumps(missing,ensure_ascii=False,indent=2));print('COMPLETE',len(need)-len(missing),'/',len(need),'missing',len(missing),flush=True)
