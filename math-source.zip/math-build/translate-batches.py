from pathlib import Path
import json,re,html,subprocess,time
query='Return ONLY a valid JSON object mapping EVERY EXACT source string in this list to its complete faithful English translation. Preserve every {{number}} placeholder, number, formula, symbol and variable. Translate all Chinese, including explanations, hints and options. Do not change answers, omit entries, summarize, or add content. JSON keys must be the source string exactly. No markdown fences.'
def parse_json(p):
 raw=p.read_text().strip();raw=re.sub(r'^```(?:json)?\s*|\s*```$','',raw);d=json.loads(raw);return d if isinstance(d,dict) else {}
def strings(x):
 if isinstance(x,str):return {x} if re.search('[\u3400-\u9fff]',x) else set()
 if isinstance(x,list):return set().union(*(strings(v) for v in x)) if x else set()
 if isinstance(x,dict):return set().union(*(strings(v) for v in x.values())) if x else set()
 return set()
def merged():
 d={}
 for p in Path('math-translations').rglob('*.json'):
  try:d.update(parse_json(p))
  except:pass
 return {k:v for k,v in d.items() if isinstance(v,str) and v and not re.search('[\u3400-\u9fff]',v)}
need=set(json.loads(Path('math-build/ui-corpus.json').read_text()))
for p in Path('math-original/data').rglob('*.json'):need.update(strings(json.loads(p.read_text())))
for round in range(4):
 d=merged();missing=sorted(need-d.keys());print('Round',round,'missing',len(missing),'of',len(need),flush=True)
 if not missing:break
 for i in range(0,len(missing),80):
  batch=missing[i:i+80];dest=Path(f'math-translations/batch-{round}-{i//80:03}.json');src=Path('math-build/translation-input/current.html');src.write_text('<html><body><pre>'+html.escape(json.dumps(batch,ensure_ascii=False))+'</pre></body></html>')
  for attempt in range(5):
   try:r=subprocess.run(['firecrawl','parse',str(src),'--query',query,'-o',str(dest)],capture_output=True,text=True,timeout=240)
   except subprocess.TimeoutExpired:print('Timeout, retry',flush=True);continue
   if r.returncode==0:
    try:
     result=parse_json(dest);dest.write_text(json.dumps(result,ensure_ascii=False,indent=2));print(dest.name,len(set(batch)&result.keys()),'/',len(batch),flush=True);break
    except Exception as e:print('Invalid JSON',e,flush=True)
   else:print('Retry',r.stderr[-180:],flush=True)
   time.sleep(20)
  time.sleep(2)
d=merged();missing=sorted(need-d.keys());Path('math-build/missing.json').write_text(json.dumps(missing,ensure_ascii=False,indent=2));Path('pcrlearing-publish/math-en.js').write_text('globalThis.MATH_EN='+json.dumps(d,ensure_ascii=False)+';');print('COMPLETE',len(need)-len(missing),'/',len(need),'missing',len(missing),flush=True)
